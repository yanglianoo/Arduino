#ifndef __KEY_H
#define __KEY_H

#define key_l PEin(0)
#define key_r PCin(13)
void KEY_Init(void);

#endif

